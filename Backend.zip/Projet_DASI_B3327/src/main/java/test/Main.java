package test;

/** @author Simon Poulet et Yannick Alpou binôme B3327 */

import com.google.maps.model.LatLng;
import dao.JpaUtil;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import metier.modele.Agence;
import metier.modele.Client;
import metier.modele.Employe;
import metier.modele.Intervention;
import metier.modele.InterventionAnimal;
import metier.modele.InterventionIncident;
import metier.modele.InterventionLivraison;
import metier.service.Services;
import util.GeoNetApi;
import static util.GeoNetApi.getLatLng;

public class Main {

    public static void main(String[] args) {
        JpaUtil.init();
        
        // DESACTIVER LES PRINTSTACKTRACE ET LOG
        
        //testerInscriptionClient();
        //testerAuthentificationClient();
        //testerAuthentificationEmploye();
        //testerDemandeIntervention();
        //testerClotureIntervention();
       // testerHistoriqueClient();
        testerHistoriqueEtDistanceEmploye();
        //UseCase();
        
        JpaUtil.destroy();        
    }
    
    public static void testerInscriptionClient() {
        
        /* Succès de l'inscription */
        System.out.println("\n----------------------------------\n"
                + "Inscription du client qui doit réussir\n"
                + "----------------------------------\n\n");
        Client c = new Client("DUPONT", "Jean", "jean.dupont@gmail.com", "test", "0625652148", (new GregorianCalendar(1998,05,06)).getTime(), "20 Av. Albert Einstein, 69100 Villeurbanne");
        Services.inscrireClient(c);
        
        /* On essaie de réinscrire un client avec la même adresse mail, ce qui viole
        la contrainte d'unicité sur la colonne */
        
        System.out.println("----------------------------------\n"
                + "Inscription du client qui doit échouer\n"
                + "----------------------------------\n\n");
        Client c2 = new Client("DUPONES", "Juan", "jean.dupont@gmail.com", "test", "0625128141", (new GregorianCalendar(1957,04,28)).getTime(), "30 Av. Einstein, 75100 Paris");
        Services.inscrireClient(c2);
        
        /* Il est à noter qu'il est possible d'inscrire un client à qui il manque une 
        information (type nom/prénom, etc...) sauf l'adresse mail qui est une clé primaire.
        La vérification que les champs sont remplis doivent se faire dans l'IHM et pas dans 
        le service. 
        */
    }
    
    public static void testerAuthentificationClient() {
        Client c = new Client("DUPONT", "Jean", "jean.dupont@gmail.com", "test", "0625652148", (new GregorianCalendar(1998,05,06)).getTime(), "20 Av. Albert Einstein, 69100 Villeurbanne");
        Services.inscrireClient(c);
        
        /* Autentification réussie */
        System.out.println("\n----------------------------------\n"
                + "Authentification du client qui doit réussir\n"
                + "----------------------------------\n\n");
        Client auth = Services.authentifierClient(c.getEmail(), c.getMotDePasse());
        
        if(auth == null) {
            System.out.println("> Pas de client trouvé avec ce login/mdp");
        }
        else {
            System.out.println("> Client trouvé avec ce login/mdp");
            System.out.println(auth);
        } 
        
        /* Échec authentification */
        System.out.println("\n----------------------------------\n"
                + "Authentification du client qui doit échouer\n"
                + "----------------------------------\n\n");
        Client auth2 = Services.authentifierClient(c.getEmail(), "cecinestpaslemdp");
        
        if(auth2 == null) {
            System.out.println("> Pas de client trouvé avec ce login/mdp");
        }
        else {
            System.out.println("> Client trouvé avec ce login/mdp");
            System.out.println(auth2);
        } 
    }
    
    public static void testerAuthentificationEmploye() {
        Services.initialiser();
        
        /* Autentification réussie */
        System.out.println("\n----------------------------------\n"
                + "Authentification de l'employé qui doit réussir\n"
                + "----------------------------------\n\n");
        Employe auth = Services.authentifierEmploye("thomas.gaudan@laposte.net", "test"); //inscrit en dur à l'initialisation
        
        if(auth == null) {
            System.out.println("> Pas d'employé trouvé avec ce login/mdp");
        }
        else {
            System.out.println("> Employé trouvé avec ce login/mdp");
            System.out.println(auth);
        } 
        
        /* Échec authentification */
        System.out.println("\n----------------------------------\n"
                + "Authentification dr l'employe qui doit échouer\n"
                + "----------------------------------\n\n");
        Employe auth2 = Services.authentifierEmploye("thomas.gaudan@laposte.net", "cecinestpaslemdp");
        
        if(auth2 == null) {
            System.out.println("> Pas d'employé trouvé avec ce login/mdp");
        }
        else {
            System.out.println("> Employé trouvé avec ce login/mdp");
            System.out.println(auth2);
        } 
    }
      
    public static void testerDemandeIntervention() {
        
        Client c = new Client("DUPONT", "Jean", "jean.dupont@gmail.com", "test", "0625652148", (new GregorianCalendar(1998,05,06)).getTime(), "20 Av. Albert Einstein, 69100 Villeurbanne ");
        Services.inscrireClient(c);
        Client c2 = new Client("ZOLA", "Pierre", "pierre.zola@gmail.com", "test", "0625782125", (new GregorianCalendar(1978,05,06)).getTime(), "15 Rue des Sciences, 69100 Villeurbanne");
        Services.inscrireClient(c2);
        Services.initialiser();
        
        //*****************************************************
        // Cas aucun problème
        InterventionAnimal i = new InterventionAnimal("Chien", "Promener mon  chien Médor", c);
        Services.ajouterIntervention(i);
        System.out.println("///////////////////////////////////////////////");
        
        //*****************************************************
        // Cas plusieurs employés et tri par distance
        InterventionIncident i2 = new InterventionIncident("MA PLOMBERIE FUIT!!!!", c);
        
        /*Recopie des infos de tous les employés et des agences */
        Employe e1 = new Employe("GAUDAN", "Thomas", "thomas.gaudan@laposte.net", "test", "0470897356", 
                                    (new GregorianCalendar(1970,12,23)).getTime(), (new GregorianCalendar(0,0,0,10,0)).getTime(), (new GregorianCalendar(0,0,0,18,0)).getTime());
        Employe e2 = new Employe("KON-SUN-TICK", "Maxime", "maxime.kon-sun-tick@hotmail.com", "test", "0195130865", 
                                    (new GregorianCalendar(1992,01,23)).getTime(), (new GregorianCalendar(0,0,0,11,0)).getTime(), (new GregorianCalendar(0,0,0,19,0)).getTime());
        Employe e3 = new Employe("DUBIURG", "Nataly", "ndubiurg529@free.fr", "test", "0756499181", 
                                    (new GregorianCalendar(1971,10,18)).getTime(), (new GregorianCalendar(0,0,0,12,0)).getTime(), (new GregorianCalendar(0,0,0,20,0)).getTime());
        Employe e4 = new Employe("DREUYOR", "Alexandra", "alexandra.dreuyor@yahoo.com@", "test", "0289080871", 
                                    (new GregorianCalendar(1991,04,12)).getTime(), (new GregorianCalendar(0,0,0,8,0)).getTime(), (new GregorianCalendar(0,0,0,16,0)).getTime());
        Employe e5 = new Employe("PHON", "Anna Christina", "anna-christina.phon@laposte.net", "test", "0634976341", 
                                    (new GregorianCalendar(1994,10,24)).getTime(), (new GregorianCalendar(0,0,0,12,0)).getTime(), (new GregorianCalendar(0,0,0,20,0)).getTime());
        Employe e6 = new Employe("GUYOMERD", "Xavier", "xavier.guyomerd@gmail.com", "test", "0459203247", 
                                    (new GregorianCalendar(1998,05,06)).getTime(), (new GregorianCalendar(0,0,0,9,0)).getTime(), (new GregorianCalendar(0,0,0,17,0)).getTime());
        
        Agence a1 = new Agence("Agence n°1", "16 Rue Pascal, Villeurbanne");
        Agence a2 = new Agence("Agence n°2", "1 Rue Jean Zuber, Villeurbanne");
        Agence a3 = new Agence("Agence n°3", "12 Rue Billon, Villeurbanne");
        
        a1.addEmploye(e1);
        e1.setAgence(a1);
        
        a1.addEmploye(e2);
        e2.setAgence(a1);
        
        a2.addEmploye(e3);
        e3.setAgence(a2);
        
        a2.addEmploye(e4);
        e4.setAgence(a2);
        
        a3.addEmploye(e5);
        e5.setAgence(a3);
        
        a3.addEmploye(e6);   
        e6.setAgence(a3);  
        
        System.out.println("Employé e1 : " + GeoNetApi.getFlightDistanceInKm(getLatLng(e1.getAgence().getAdresse()),
                                                                             new LatLng(c.getLatitude(),c.getLongitude())) + " km pour aller chez le client\n");
        System.out.println("Employé e2 : " + GeoNetApi.getFlightDistanceInKm(getLatLng(e2.getAgence().getAdresse()),
                                                                             new LatLng(c.getLatitude(),c.getLongitude())) + " km pour aller chez le client\n");
        System.out.println("Employé e3 : " + GeoNetApi.getFlightDistanceInKm(getLatLng(e3.getAgence().getAdresse()),
                                                                             new LatLng(c.getLatitude(),c.getLongitude())) + " km pour aller chez le client\n");
        System.out.println("Employé e4 : " + GeoNetApi.getFlightDistanceInKm(getLatLng(e4.getAgence().getAdresse()),
                                                                             new LatLng(c.getLatitude(),c.getLongitude())) + " km pour aller chez le client\n");
        System.out.println("Employé e5 : " + GeoNetApi.getFlightDistanceInKm(getLatLng(e5.getAgence().getAdresse()),
                                                                             new LatLng(c.getLatitude(),c.getLongitude())) + " km pour aller chez le client\n");
        System.out.println("Employé e6 : " + GeoNetApi.getFlightDistanceInKm(getLatLng(e6.getAgence().getAdresse()),
                                                                             new LatLng(c.getLatitude(),c.getLongitude())) + " km pour aller chez le client\n");
                
        Services.ajouterIntervention(i2);
        System.out.println("Employé choisi par le service : " + i2.getEmploye() + "\n");
        System.out.println("///////////////////////////////////////////////");
        
        //*****************************************************
        // Cas aucun employé 1 : en dehors des heures de dispo
        
        InterventionIncident itest = new InterventionIncident("Problème de plaque électrique", c);
        itest.setDateDemande((new GregorianCalendar(0,0,0,0,0)).getTime()); //demande à minuit
        System.out.println(itest);
        Services.ajouterIntervention(itest);
        System.out.println("///////////////////////////////////////////////");
                
        //*****************************************************
        // Cas aucun employé 2 : tous occupés
        
        InterventionIncident i3 = new InterventionIncident("MA PLOMBERIE FUIT!!!! v2", c2);
        InterventionIncident i4 = new InterventionIncident("MA PLOMBERIE FUIT!!!! v3", c2);
        InterventionIncident i5 = new InterventionIncident("MA PLOMBERIE FUIT!!!! v4", c);
        InterventionLivraison i6 = new InterventionLivraison("Canapé", "MeublesClassieux SAS", "Déposez dans salon svp", c);
        InterventionAnimal i7 = new InterventionAnimal("Tigre", "Promenez mon tigre svp", c);

        Services.ajouterIntervention(i3);
        Services.ajouterIntervention(i4);
        System.out.println(Services.ajouterIntervention(i5));   //ajoutée
        System.out.println(Services.ajouterIntervention(i6));   //non ajoutée
        System.out.println(Services.ajouterIntervention(i7));   //non ajoutée
              
    }
    
    public static void testerClotureIntervention() {
       
        Client c = new Client("DUPONT", "Jean", "jean.dupont@gmail.com", "test", "0625652148", (new GregorianCalendar(1998,05,06)).getTime(), "20 Av. Albert Einstein, 69100 Villeurbanne");
        Services.inscrireClient(c);
        Services.initialiser();
        
        InterventionAnimal i7 = new InterventionAnimal("Tigre", "Promenez mon tigre svp", c);
        System.out.println(i7);
        Services.ajouterIntervention(i7);
        Services.terminerInterventionEnCours(i7.getEmploye(), true, "Il m'a mordu la main mais à part ça aucun problème :)");
        
        System.out.println("///////////////////////////////////////////////");

        // Test si aucune intervention en cours : 
        System.out.println(Services.terminerInterventionEnCours(i7.getEmploye(), true, "Il m'a mordu la main mais à part ça aucun problème :)"));
        
    }
    
    public static void testerHistoriqueClient() {
        Client c = new Client("DUPONT", "Jean", "jean.dupont@gmail.com", "test", "0625652148", (new GregorianCalendar(1998,05,06)).getTime(), "20 Av. Albert Einstein, 69100 Villeurbanne");
        Services.inscrireClient(c);
        Services.initialiser();
        
        InterventionIncident i3 = new InterventionIncident("MA PLOMBERIE FUIT!!!! v2", c);
        InterventionIncident i4 = new InterventionIncident("MA PLOMBERIE FUIT!!!! v3", c);
        InterventionIncident i5 = new InterventionIncident("MA PLOMBERIE FUIT!!!! v4", c);
        //InterventionLivraison i6 = new InterventionLivraison("Canapé", "MeublesClassieux SAS", "Déposez dans salon svp", c);
        InterventionAnimal i7 = new InterventionAnimal("Tigre", "Promenez mon tigre svp", c);

        Services.ajouterIntervention(i3);
        Services.ajouterIntervention(i4);
        Services.ajouterIntervention(i5);
        //Services.ajouterIntervention(i6);
        Services.ajouterIntervention(i7);
        
        Services.terminerInterventionEnCours(i7.getEmploye(), true, "Il m'a mordu la main mais à part ça aucun problème :)");

        List<Intervention> liste = Services.obtenirHistoriqueClient(c);
        
        for(Intervention i : liste) {
            System.out.println(i + "\n");
        } 
    }
    
    public static void testerHistoriqueEtDistanceEmploye() {
        
        Client c = new Client("DUPONT", "Jean", "jean.dupont@gmail.com", "test", "0625652148", (new GregorianCalendar(1998,05,06)).getTime(), "20 Av. Albert Einstein, 69100 Villeurbanne");
        Services.inscrireClient(c);
        Services.initialiser();
        
        // AJOUTs DES INTERVENTIONS 
        
        
        InterventionIncident itest = new InterventionIncident("Problème de plaque électrique", c);
        InterventionLivraison i6 = new InterventionLivraison("Canapé", "MeublesClassieux SAS", "Déposez dans salon svp", c);
        InterventionAnimal i7 = new InterventionAnimal("Tigre", "Promenez mon tigre svp", c);
        InterventionAnimal i8 = new InterventionAnimal("Chat", "Nourrissez mon chat svp", c);
        InterventionAnimal i9 = new InterventionAnimal("Chien", "Promenez mon chien svp", c);
        
        // Comme un seul employé travaille entre 8 et 9h, on place toutes les demandes 
        // à ce moment là
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 8);
        calendar.set(Calendar.MINUTE, 1);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date allDemandes = calendar.getTime();
        
        itest.setDateDemande(allDemandes); //demande à 08h01
        i6.setDateDemande(allDemandes); //demande à 08h01
        i7.setDateDemande(allDemandes); //demande à 08h01
        
        calendar.add(Calendar.DAY_OF_MONTH,-1);
        i8.setDateDemande(calendar.getTime()); //demande la veille à 08h01
        
        Services.ajouterIntervention(itest);
        Services.terminerInterventionEnCours(itest.getEmploye(), true, "inter 1");
        
        Services.ajouterIntervention(i6);
        Services.terminerInterventionEnCours(i6.getEmploye(), true, "inter 2");
        
        Services.ajouterIntervention(i7);
        Services.terminerInterventionEnCours(i7.getEmploye(), true, "inter 3");
        
        Services.ajouterIntervention(i8);
        Services.terminerInterventionEnCours(i8.getEmploye(), true, "inter 4");
        
        Services.ajouterIntervention(i9);
        // Historique et distance 
        
        List<Intervention> liste = Services.obtenirJourneeEmploye(itest.getEmploye());
        for(Intervention i : liste) {
            System.out.println(i + "\n");
        } 
        
        System.out.println("DISTANCE : " + Services.obtenirDistanceJourneeEmploye(itest.getEmploye()));
    }
    
    public static void UseCase() {
        
        Services.initialiser();
        
        /* Côté client*/
        Services.inscrireClient(new Client("DUPONT", "Jean", "jean.dupont@gmail.com", 
                "test", "0625652148", (new GregorianCalendar(1998,05,06)).getTime(), "20 Av. Albert Einstein, 69100 Villeurbanne"));
        
        Client clientConnecte =  Services.authentifierClient("jean.dupont@gmail.com","test");
        Intervention i = new InterventionIncident("Mon chauffage ne fonctionne pas",clientConnecte);
        Services.ajouterIntervention(i);
        System.out.println(Services.obtenirHistoriqueClient(clientConnecte));
        System.out.println("////////////////////////////////////////");
        
        /*Côté Employé*/
        //Connexion de l'employé à qui la tâche a été affectée
        Employe empConnecte = Services.authentifierEmploye(i.getEmploye().getEmail(),i.getEmploye().getMotDePasse());
        Services.terminerInterventionEnCours(empConnecte, Boolean.TRUE, "Le chauffage est réparé !");
        System.out.println(Services.obtenirJourneeEmploye(empConnecte));
        System.out.println(Services.obtenirDistanceJourneeEmploye(empConnecte) + " km parcourus aujourd'hui !");
    }
}
