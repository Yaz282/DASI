/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.modele;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@Inheritance (strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Personne implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    protected Long id;
    protected String nom;
    protected String prenom;
    @Column(unique=true)
    protected String email;
    protected String numTel;
    //@Temporal(TemporalType.DATE)
    
    @Temporal(javax.persistence.TemporalType.DATE)
    protected Date dateNaissance; 

    public Personne(String nom, String prenom, String email, String numTel, Date dateNaissance) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.numTel = numTel;
        this.dateNaissance = dateNaissance;
    }

    public Personne() {
    }

    public Long getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String numTel) {
        this.numTel = numTel;
    }

    public Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    @Override
    public String toString() {
        return "Personne{" + "id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", numTel=" + numTel + ", dateNaissance=" + dateNaissance + '}';
    }
    
    
    
}
