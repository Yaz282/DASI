/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.modele;

import java.io.Serializable;
import javax.persistence.Entity;

@Entity
public class InterventionAnimal extends Intervention implements Serializable{
    String animal;

    public InterventionAnimal(String animal, String description, Client client) {
        super(description, client);
        this.animal = animal;
    }

    public InterventionAnimal() {
    }


    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }
    
    @Override
    public String toString() {
        return super.toString() + "\nInterventionAnimal{" + "animal=" + animal + '}';
    }
}
