/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fkoch
 */
 package action;

import javax.servlet.http.HttpServletRequest;
import metier.modele.Client;
import metier.service.Services;


 public class ActionAuthentification extends Action { 
// Héritage de la classe abstraite Action

 @Override
     public void executer(HttpServletRequest request) { // Implémentation de la méthode Action.executer()

         // Récupération des Paramètres de la Requête
         String login = request.getParameter("login");
         System.out.println(login);
         String password = request.getParameter("password");

         // Instanciation de la classe de Service
         Services service = new Services();

         // Appel des Services Métiers (= méthodes de la classe de Service)
         Client client = service.authentifierClient(login, password);
         // Vérifier le retour de la fonction authentifier pour gérer si c'est null : Gérer  nous même le cas ou client est nul donc mdp erroné

         // Stockage des Résultats dans les Attributs de la Requête
         request.setAttribute("login", login);
         request.setAttribute("password", password);
         request.setAttribute("client", client);      
         

         // If pour vérifier si authentification client ou Authentifcation Employee 

     }

 }
    /*public ActionAuthentification(Service service) {
        super(service);
    }*/