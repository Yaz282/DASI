/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.insalyon.dasi.educatif.ihm.web.serialisation;

/**
 *
 * @author fkoch
 */

 import com.google.gson.Gson;
 import com.google.gson.GsonBuilder;
 import com.google.gson.JsonArray;
 import com.google.gson.JsonObject;
 import java.io.IOException;
 import java.io.PrintWriter;
 import java.util.List;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
import metier.modele.Client;
import metier.modele.Employe;
import static metier.modele.Intervention_.client;


 public class SerialisationAuthentificationEmploye extends Serialisation { // Héritage de la classe abstraite Serialisation

 @Override
    public void serialiser(HttpServletRequest request, HttpServletResponse response) throws IOException { // Implémentation de la méthode Serialisation.serialiser()

        JsonObject container = new JsonObject(); // Objet "conteneur JSON" pour structurer les données à sérialiser

        // Lecture des Attributs de la Requête (stockés par l'Action)
        String login = (String) request.getAttribute("login");
        String password = (String) request.getAttribute("password");
        Employe employe = (Employe) request.getAttribute("employe");

        // Ajout de propriétés au conteneur JSON: promo et effectif
        if(employe != null)
        {
        container.addProperty("connexion", true);
        request.getSession().setAttribute("idEmploye", employe.getId());
        }else
        {
         container.addProperty("connexion", false);
        }


// Formattage de la structure de données JSON => Écriture sur le flux de sortie de la Réponse
        PrintWriter out = this.getWriter(response);
        Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
        gson.toJson(container, out);
        out.close();
    }

}
