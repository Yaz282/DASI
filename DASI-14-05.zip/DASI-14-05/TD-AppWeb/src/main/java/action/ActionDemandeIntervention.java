/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fkoch
 */
 package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import metier.modele.Client;
import metier.modele.Employe;
import metier.modele.Intervention;
import metier.modele.InterventionAnimal;
import metier.modele.InterventionIncident;
import metier.modele.InterventionLivraison;
import metier.service.Services;


 public class ActionDemandeIntervention extends Action { 
// Héritage de la classe abstraite Action

 @Override
     public void executer(HttpServletRequest request) { // Implémentation de la méthode Action.executer()

         // Récupération des Paramètres de la Requête
        HttpSession session =request.getSession();
        long id = (int) session.getAttribute("id");
        Client client = Services.trouverClientParID(id);
        
        String description = (String) session.getAttribute("description");
        String DType = (String) session.getAttribute("type");
        Intervention monIntervention=null;
        
        if(DType=="InterventionAnimal"){
              String animal = (String) session.getAttribute("animal");
               monIntervention = new InterventionAnimal(animal,description,client);
       }
        else if (DType == "InterventionIncident") {
          monIntervention = new InterventionIncident(description, client);
     } 
        else if (DType == "InterventionLivraison") {
            String entreprise = (String) session.getAttribute("entreprise");
            String objet = (String) session.getAttribute("objet");

             monIntervention = new InterventionLivraison(entreprise, objet, description, client);
        }

        // Instanciation de la classe de Service
        Services service = new Services();

        // Appel des Services Métiers (= méthodes de la classe de Service)
        int verif = service.ajouterIntervention(monIntervention);

        // Vérifier le retour de la fonction authentifier pour gérer si c'est null : Gérer  nous même le cas ou client est nul donc mdp erroné
        // Stockage des Résultats dans les Attributs de la Requête
        request.setAttribute("verif", verif);
        request.setAttribute("Intervention", monIntervention);

        // Bien revoir les dates 
    }

}
