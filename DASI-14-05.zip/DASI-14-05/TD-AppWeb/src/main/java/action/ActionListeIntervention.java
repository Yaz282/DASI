/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author fkoch
 */
package action;

import static java.util.Collections.list;
import javax.servlet.http.HttpServletRequest;
import metier.modele.Client;
import metier.service.Services;
import java.util.List;
import javax.servlet.http.HttpSession;
import metier.modele.Intervention;
import static metier.service.Services.trouverClientParID;


public class ActionListeIntervention extends Action {

    @Override
    public void executer(HttpServletRequest request) { // Implémentation de la méthode Action.executer()

        // Récupération des Paramètres de la Requête
        HttpSession session = request.getSession(true);
            long id = (int) session.getAttribute("id");
            Client client = trouverClientParID(id);

        // Instanciation de la classe de Service
        Services service = new Services();

        // Appel des Services Métiers (= méthodes de la classe de Service)
        List<Intervention> liste = service.obtenirHistoriqueClient(client);


        // Stockage des Résultats dans les Attributs de la Requête
        request.setAttribute("listeIntervention", liste);

    }

}
