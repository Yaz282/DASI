/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fkoch
 */
 package action;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import metier.modele.Client;
import metier.service.Services;


 public class ActionInscription extends Action { 
// Héritage de la classe abstraite Action

 @Override
     public void executer(HttpServletRequest request) { // Implémentation de la méthode Action.executer()

         // Récupération des Paramètres de la Requête
         String nom = request.getParameter("nom");
         String prenom = request.getParameter("prenom");
         String mail = request.getParameter("mail");
         String tel = request.getParameter("tel");
         String dateNaissance = request.getParameter("dateNaissance");
         String adresse = request.getParameter("adresse");
         String motDePasse = request.getParameter("motDePasse");

         // Instanciation de la classe de Service
         Services service = new Services();

         Date date=new SimpleDateFormat("dd/MM/yyyy").parse(dateNaissance);  
        Client client = new Client(nom,prenom, mail,  motDePasse, tel, date,adresse);
         // Appel des Services Métiers (= méthodes de la classe de Service)
         int verif = service.inscrireClient(client);
         // Vérifier le retour de la fonction authentifier pour gérer si c'est null : Gérer  nous même le cas ou client est nul donc mdp erroné

         // Stockage des Résultats dans les Attributs de la Requête
         request.setAttribute("client", client);    

         // If pour vérifier si authentification client ou Authentifcation Employee 

     }

 }
    /*public ActionAuthentification(Service service) {
        super(service);
    }*/


