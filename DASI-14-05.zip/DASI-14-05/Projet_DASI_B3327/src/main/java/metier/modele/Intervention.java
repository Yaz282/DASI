/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.modele;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;

@Entity
@Inheritance (strategy = InheritanceType.SINGLE_TABLE)
public abstract class Intervention implements Serializable {
    
    public enum Stat{EN_COURS, REUSSIE, ECHOUEE};
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date dateDemande;
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date dateCloture;
    private String description;
    private String commentaire;
    private Stat statut;
    
    @ManyToOne
    private Client client;
    
    @ManyToOne
    private Employe employe;

    public Intervention(String description, Client client) {
        this.dateDemande = new Date();
        this.description = description;
        this.client = client;
        this.employe = null;
        this.statut = Stat.EN_COURS;
    }
    
    public Intervention() {
    }

    public Date getDateDemande() {
        return dateDemande;
    }

    public void setDateDemande(Date dateDemande) {
        this.dateDemande = dateDemande;
    }

    public Date getDateCloture() {
        return dateCloture;
    }

    public void setDateCloture(Date dateCloture) {
        this.dateCloture = dateCloture;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Stat getStatut() {
        return statut;
    }

    public void setStatut(Stat statut) {
        this.statut = statut;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Employe getEmploye() {
        return employe;
    }

    public void setEmploye(Employe employe) {
        this.employe = employe;
    }

    @Override
    public String toString() {
        return "Intervention{" + "id=" + id + ", dateDemande=" + dateDemande + ", dateCloture=" + dateCloture + ", description=" + description + ", commentaire=" + commentaire + ", statut=" + statut + ", client=" + client + ", employe=" + employe + '}';
    }
    
    
}

