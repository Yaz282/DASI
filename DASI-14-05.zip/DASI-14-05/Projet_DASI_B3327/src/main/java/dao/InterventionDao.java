/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package dao;

import javax.persistence.EntityManager;
import metier.modele.Intervention;

public class InterventionDao {
    
    public static void persisterIntervention(Intervention i) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        em.persist(i);
    }
    
    public static void appliquerModifsIntervention(Intervention i) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        
        em.merge(i);
    }
}
