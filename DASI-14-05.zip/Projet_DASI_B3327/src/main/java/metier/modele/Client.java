/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.modele;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Entity
public class Client extends Personne {
    
    private String motDePasse;
    private Double longitude = null;
    private Double latitude = null;
    private String adresse;
    
    // Un client peut demander plusieurs interventions
    private List<Intervention> interEnCours;

    public Client(String nom, String prenom, String email, String motDePasse, String numTel, Date dateNaissance, String adresse) {
        super(nom, prenom, email, numTel, dateNaissance);
        this.motDePasse = motDePasse;
        this.adresse = adresse;
        this.interEnCours = new ArrayList<Intervention>();
    }

    public Client() {
        super();
    }
    
    public List<Intervention> getInterEnCours() {
        return interEnCours;
    }

    public void addIntervention(Intervention i) {
        this.interEnCours.add(i);
    }
    
    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    @Override
    public String toString() {
        return super.toString() + "\nClient{" + "motDePasse=" + motDePasse + ", longitude=" + longitude + ", latitude=" + latitude + ", adresse=" + adresse + '}';
    }
   
    
    
}
