/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.modele;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
public class Employe extends Personne implements Serializable {
    
    private String motDePasse;
    @Temporal(javax.persistence.TemporalType.TIME)
    private Date horaireDeb;
    @Temporal(javax.persistence.TemporalType.TIME)
    private Date horaireFin;
    @ManyToOne  
    private Agence agence;
    
    //@OneToMany(mappedBy="employe")
    //private List<Intervention>listeInter;

    private Intervention interEnCours;

    public Employe(String nom, String prenom, String email, String motDePasse, String numTel, 
                    Date dateNaissance, Date horaireDeb, Date horaireFin) {
        super(nom, prenom, email, numTel, dateNaissance);
        this.motDePasse = motDePasse;
        this.horaireDeb = horaireDeb;
        this.horaireFin = horaireFin;
        this.agence = null;
        this.interEnCours = null;
    }

    public Employe() {
        super();
    }
    
    public Intervention getInterEnCours() {
        return interEnCours;
    }

    public void setInterEnCours(Intervention i) {
        this.interEnCours = i;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public Date getHoraireDeb() {
        return horaireDeb;
    }

    public void setHoraireDeb(Date horaireDeb) {
        this.horaireDeb = horaireDeb;
    }

    public Date getHoraireFin() {
        return horaireFin;
    }

    public void setHoraireFin(Date horaireFin) {
        this.horaireFin = horaireFin;
    }

    public Agence getAgence() {
        return agence;
    }

    public void setAgence(Agence agence) {
        this.agence = agence;
    }

    @Override
    public String toString() {
        return super.toString() + "\nEmploye{" + "motDePasse=" + motDePasse + ", horaireDeb=" + horaireDeb + ", horaireFin=" + horaireFin + ", agence=" + agence + '}';
    }  
    
}
