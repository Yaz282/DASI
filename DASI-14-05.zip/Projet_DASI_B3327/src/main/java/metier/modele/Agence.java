/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.modele;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Agence implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    protected Long id;
    private String nom;
    private String adresse;
    private Double longitude;
    private Double latitude;
    @OneToMany(mappedBy="agence")
    private List<Employe>listeEmploye;

    public Agence(String nom, String adresse) {
        this.nom = nom;
        this.adresse = adresse;
        this.listeEmploye = new ArrayList<Employe>();

    }

    public Agence() {
    }

    public Long getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }
    
    public void addEmploye(Employe e){
        this.listeEmploye.add(e);
    }

    @Override
    public String toString() {
        return "Agence{" + "nom=" + nom + ", adresse=" + adresse + ", longitude=" + longitude + ", latitude=" + latitude + '}';
    }
    
}
