/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.modele;

import java.io.Serializable;
import javax.persistence.Entity;

@Entity
public class InterventionIncident extends Intervention implements Serializable{

    public InterventionIncident(String description, Client client) {
        super(description, client);
    }

    public InterventionIncident() {
    }
        
    @Override
    public String toString() {
        return super.toString() + "\nInterventionIncident{}";
    }
}
