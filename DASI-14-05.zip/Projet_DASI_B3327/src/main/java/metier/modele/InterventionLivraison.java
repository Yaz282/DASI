/** @author Simon Poulet et Yannick Alpou binôme B3327 */
package metier.modele;

import java.io.Serializable;
import javax.persistence.Entity;

@Entity
public class InterventionLivraison extends Intervention implements Serializable{
    String entreprise;
    String objet;

    public InterventionLivraison(String entreprise, String objet, String description, Client client) {
        super(description, client);
        this.entreprise = entreprise;
        this.objet = objet;
    }

    public InterventionLivraison() {
    }
    
    
    public String getEntreprise() {
        return entreprise;
    }

    public void setEntreprise(String entreprise) {
        this.entreprise = entreprise;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    @Override
    public String toString() {
        return super.toString() + "\nInterventionLivraison{" + "entreprise=" + entreprise + ", objet=" + objet + '}';
    }

    
}
