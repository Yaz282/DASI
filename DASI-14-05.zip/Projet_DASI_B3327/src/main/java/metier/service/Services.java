/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package metier.service;

import com.google.maps.model.LatLng;

import dao.AgenceDao;
import dao.ClientDao;
import dao.EmployeDao;
import dao.InterventionDao;
import dao.JpaUtil;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import metier.modele.Client;
import metier.modele.Agence;
import metier.modele.Employe;
import metier.modele.Intervention;

import util.GeoNetApi;
import static util.GeoNetApi.getLatLng;
import util.Message;

public class Services {
    
    //Section client
    
    private static void majAdresseClient(String adresse, Client c) {
        try{
            c.setAdresse(adresse);
            LatLng temp = getLatLng(adresse);
            c.setLatitude(temp.lat);
            c.setLongitude(temp.lng);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public static int inscrireClient(Client c) {
        
        int returnValue = -1;
        
        JpaUtil.creerContextePersistance();
              
        try {
            majAdresseClient(c.getAdresse(), c); //Bien update long lat
            JpaUtil.ouvrirTransaction();
            ClientDao.persisterClient(c);
            JpaUtil.validerTransaction();
            returnValue = 1;
            String texteMail = "Bonjour " + c.getPrenom() + ", nous vous confirmons votre inscription au service REACT'IF. Un cas d'urgence ?"
                                    +" Rendez-vous vite sur notre site, vous pouvez compter sur nous pour résoudre votre problème avec rapidité et efficacité.";
            String objetMail = "Bienvenue chez REACT'IF";
            Message.envoyerMail("contact@react.if", c.getEmail(), objetMail, texteMail);
        }
        catch(Exception e) {
            JpaUtil.annulerTransaction();
            e.printStackTrace();
            returnValue = -1;
            String texteMail = "Bonjour " + c.getPrenom() + ", votre inscription au service REACT'IF a malencontreusement échoué..."
                                    +" Merci de recommencer ultérieurement.";
            String objetMail = "Échec de l'inscription chez REACT'IF";
            Message.envoyerMail("contact@react.if", c.getEmail(), objetMail, texteMail);
        }
        finally {
            JpaUtil.fermerContextePersistance();
        }
        
        return returnValue;
        
    }
    
    public static Client authentifierClient(String email, String mdp) {
        
        JpaUtil.creerContextePersistance();
        Client c = ClientDao.authentifierDAO(email, mdp);
        JpaUtil.fermerContextePersistance();
        return c;
    }
    
    public static List<Intervention> obtenirHistoriqueClient(Client c) {
        JpaUtil.creerContextePersistance();
        List<Intervention> liste = ClientDao.listerHistoInterventionsDAO(c);
        JpaUtil.fermerContextePersistance();
        return liste;
    }
    
    public static Client trouverClientParID(Long id) {
        JpaUtil.creerContextePersistance();
        Client c = ClientDao.trouverClientIdDAO(id);
        JpaUtil.fermerContextePersistance();
        return c;
    }
    
    //Section Agences et Employes
    
    private static Agence majCoordonnees(Agence a) {
        try{
            LatLng temp = getLatLng(a.getAdresse());
            a.setLatitude(temp.lat);
            a.setLongitude(temp.lng);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return a;
    }
    
    public static int initialiser() {
        
        Agence a1 = majCoordonnees(new Agence("Agence n°1", "16 Rue Pascal, Villeurbanne"));
        Agence a2 = majCoordonnees(new Agence("Agence n°2", "1 Rue Jean Zuber, Villeurbanne"));
        Agence a3 = majCoordonnees(new Agence("Agence n°3", "12 Rue Billon, Villeurbanne"));
        
        Employe e1 = new Employe("GAUDAN", "Thomas", "thomas.gaudan@laposte.net", "test", "0470897356", 
                                    (new GregorianCalendar(1970,12,23)).getTime(), (new GregorianCalendar(0,0,0,10,0)).getTime(), (new GregorianCalendar(0,0,0,18,0)).getTime());
        Employe e2 = new Employe("KON-SUN-TICK", "Maxime", "maxime.kon-sun-tick@hotmail.com", "test", "0195130865", 
                                    (new GregorianCalendar(1992,01,23)).getTime(), (new GregorianCalendar(0,0,0,11,0)).getTime(), (new GregorianCalendar(0,0,0,19,0)).getTime());
        Employe e3 = new Employe("DUBIURG", "Nataly", "ndubiurg529@free.fr", "test", "0756499181", 
                                    (new GregorianCalendar(1971,10,18)).getTime(), (new GregorianCalendar(0,0,0,12,0)).getTime(), (new GregorianCalendar(0,0,0,20,0)).getTime());
        Employe e4 = new Employe("DREUYOR", "Alexandra", "alexandra.dreuyor@yahoo.com@", "test", "0289080871", 
                                    (new GregorianCalendar(1991,04,12)).getTime(), (new GregorianCalendar(0,0,0,8,0)).getTime(), (new GregorianCalendar(0,0,0,16,0)).getTime());
        Employe e5 = new Employe("PHON", "Anna Christina", "anna-christina.phon@laposte.net", "test", "0634976341", 
                                    (new GregorianCalendar(1994,10,24)).getTime(), (new GregorianCalendar(0,0,0,12,0)).getTime(), (new GregorianCalendar(0,0,0,20,0)).getTime());
        Employe e6 = new Employe("GUYOMERD", "Xavier", "xavier.guyomerd@gmail.com", "test", "0459203247", 
                                    (new GregorianCalendar(1998,05,06)).getTime(), (new GregorianCalendar(0,0,0,9,0)).getTime(), (new GregorianCalendar(0,0,0,17,0)).getTime());
        
        a1.addEmploye(e1);
        e1.setAgence(a1);
        
        a1.addEmploye(e2);
        e2.setAgence(a1);
        
        a2.addEmploye(e3);
        e3.setAgence(a2);
        
        a2.addEmploye(e4);
        e4.setAgence(a2);
        
        a3.addEmploye(e5);
        e5.setAgence(a3);
        
        a3.addEmploye(e6);   
        e6.setAgence(a3);
                
        int returnValue = -1;
        
        JpaUtil.creerContextePersistance();
       
        try {
            JpaUtil.ouvrirTransaction();
            
            AgenceDao.persisterAgence(a1);
            AgenceDao.persisterAgence(a2);
            AgenceDao.persisterAgence(a3);
            
            EmployeDao.persisterEmploye(e1);
            EmployeDao.persisterEmploye(e2);
            EmployeDao.persisterEmploye(e3);
            EmployeDao.persisterEmploye(e4);
            EmployeDao.persisterEmploye(e5);
            EmployeDao.persisterEmploye(e6);
            
            JpaUtil.validerTransaction();
            returnValue = 1;
        }
        catch(Exception e) {
            JpaUtil.annulerTransaction();
            e.printStackTrace();
            returnValue = -1;
        }
        finally {
            JpaUtil.fermerContextePersistance();
        }
        
        return returnValue;
    }
    
    public static Employe authentifierEmploye(String email, String mdp) {
        JpaUtil.creerContextePersistance();
        Employe e = EmployeDao.authentifierDAO(email, mdp);
        JpaUtil.fermerContextePersistance();
        return e;
    }
    
    public static List<Intervention> obtenirJourneeEmploye(Employe e) {
        JpaUtil.creerContextePersistance();
        List<Intervention> liste = EmployeDao.listerInterventionsJourneeDAO(e);
        JpaUtil.fermerContextePersistance();
        return liste;
    }
    
    public static double obtenirDistanceJourneeEmploye(Employe e) {
        List<Intervention> liste = obtenirJourneeEmploye(e);
        double distanceTotale = 0;
        LatLng emp = new LatLng(e.getAgence().getLatitude(),e.getAgence().getLongitude());
        
        for(Intervention i : liste) {
            LatLng cli = new LatLng(i.getClient().getLatitude(),i.getClient().getLongitude());
            distanceTotale += GeoNetApi.getTripDurationByBicycleInMinute(emp,cli);
        }
        
        return distanceTotale;
    }
    
    public static Employe trouverEmployeParID(Long id) {
        JpaUtil.creerContextePersistance();
        Employe e = EmployeDao.trouverEmployeIdDAO(id);
        JpaUtil.fermerContextePersistance();
        return e;
    }
    
    // Section Intervention
    
    /* Renvoie -2 si aucun employé n'est disponible, -1 si erreur de màj du contexte
    de persistance et 1 si tout  s'est bien passé et que l'intervention est créée.
    */
    public static int ajouterIntervention(Intervention i) {
        
        JpaUtil.creerContextePersistance();
        
        Client c = i.getClient();
        
        //Vérifier qu'un employé est dispo 
        Date dateDemande = i.getDateDemande();    //heure actuelle
        List<Employe> listeEmp = EmployeDao.listerEmployesDisposDAO(dateDemande);
        
        if(listeEmp.isEmpty()) {
            JpaUtil.fermerContextePersistance();
            return -2;
        }
             
        //Sélectionner l'employé le plus proche       
        double min = 99999999;
        Employe empProche = null;
        LatLng cli = new LatLng(c.getLatitude(),c.getLongitude());
        
        for(Employe e:listeEmp) {
            LatLng ag = new LatLng(e.getAgence().getLatitude(),e.getAgence().getLongitude());
            //double time = GeoNetApi.getTripDurationByBicycleInMinute(ag,cli); 
            //Pour éviter trop d'appels à l'API, on utilise la distance vol d'oiseau
            double time = GeoNetApi.getFlightDistanceInKm(ag,cli);
            
            if(time < min) {
                min = time;
                empProche = e;
            }
        }
                
        int returnValue = -1;
              
        try {
            empProche.setInterEnCours(i);
            c.addIntervention(i);
            i.setEmploye(empProche);
            
            JpaUtil.ouvrirTransaction();
            InterventionDao.persisterIntervention(i);
            ClientDao.appliquerModifsClient(c);
            EmployeDao.appliquerModifsEmploye(empProche);
            JpaUtil.validerTransaction();
            returnValue = 1;
            
            String texteNotif = "Bonjour " + empProche.getPrenom() + ". Merci de prendre en charge l'intervention \"" + i.getClass().getName().substring(26)  //on print le type d'intervention
                                + "\" demandée à " + i.getDateDemande().getHours() + "h" + i.getDateDemande().getMinutes() + " par " + c.getPrenom() + " " + c.getNom()
                                + " au " + c.getAdresse() + ".";
            Message.envoyerNotification(c.getNumTel(),texteNotif);
        }
        catch(Exception e) {
            JpaUtil.annulerTransaction();
            e.printStackTrace();
            returnValue = -1;
        }
        finally {
            JpaUtil.fermerContextePersistance();
        }
        
        return returnValue;
    }
    
    /* Renvoie -2 si aucune intervention en cours, -1 si erreur de màj du contexte
    de persistance et 1 si tout  s'est bien passé et que l'intervention est clotûrée.
    */
    public static int terminerInterventionEnCours(Employe e, Boolean Succes, String commentaire) {
    
        Intervention i = e.getInterEnCours();
        if (i == null) {
            return -2;
        }
        
        JpaUtil.creerContextePersistance();
        
        int returnValue = -1;
        
        try {
            
            //Retirer de la liste du client et de l'employé
            e.setInterEnCours(null);
            Client c = i.getClient();
            c.getInterEnCours().remove(i);
            
            // Changer le statut de l'intervention
            i.setDateCloture(new Date());
            i.setCommentaire(commentaire);
            
            if(Succes) {
                i.setStatut(Intervention.Stat.REUSSIE);
            }
            else {
                i.setStatut(Intervention.Stat.ECHOUEE);
            }
            
            JpaUtil.ouvrirTransaction();
            ClientDao.appliquerModifsClient(c);
            EmployeDao.appliquerModifsEmploye(e);
            InterventionDao.appliquerModifsIntervention(i);
            JpaUtil.validerTransaction();
            returnValue = 1;
            
            /* Notification client */
            String texteNotif = "Bonjour " + c.getPrenom() + ". votre demande d'intervention du " + i.getDateDemande().getDate()+ "/" + (i.getDateDemande().getMonth()+1) + "/" + (i.getDateDemande().getYear()+1900)
                                    + " à " + i.getDateDemande().getHours() + "h" + i.getDateDemande().getMinutes() + " a été clotûrée à " + i.getDateCloture().getHours() + "h" + i.getDateCloture().getMinutes() 
                                    + ". " + i.getCommentaire() + "\nCordialement " + e.getPrenom() + ".";
            Message.envoyerNotification(c.getNumTel(),texteNotif);
        }
        catch(Exception exc) {
            JpaUtil.annulerTransaction();
            exc.printStackTrace();
            returnValue = -1;
        }
        finally {
            JpaUtil.fermerContextePersistance();
        }
        
        return returnValue;
    }
}
