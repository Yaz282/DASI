/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package dao;

import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import metier.modele.Client;
import metier.modele.Intervention;

public class ClientDao {
    
    public static void persisterClient(Client c) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        
        em.persist(c);
    }
    
    public static void appliquerModifsClient(Client c) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        
        em.merge(c);
    }
    
    public static Client trouverClientIdDAO(Long id) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        try{
            TypedQuery<Client> TypedQuery = em.createQuery("SELECT c FROM Client c WHERE c.id = :m", Client.class);
            TypedQuery.setParameter("m", id);
            return TypedQuery.getSingleResult();
        }
        catch (javax.persistence.NoResultException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static List<Intervention> listerHistoInterventionsDAO(Client c) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
               
        try{
            Query query = em.createQuery("SELECT i FROM Intervention i WHERE i.client = :c AND i.dateDemande < :date");
            query.setParameter("c",c);
            query.setParameter("date",new Date());
            return query.getResultList();
        }
        catch (javax.persistence.NoResultException exc) {
            exc.printStackTrace();
            return null;
        }
    }
    
    public static Client authentifierDAO(String email, String mdp) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        try{
            TypedQuery<Client> TypedQuery = em.createQuery("SELECT c FROM Client c WHERE c.email = :m AND c.motDePasse = :mdpd", Client.class);
            TypedQuery.setParameter("m", email);
            TypedQuery.setParameter("mdpd", mdp);
            return TypedQuery.getSingleResult();
        }
        catch (javax.persistence.NoResultException e) {
            e.printStackTrace();
            return null;
        }
    }
}
