/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package dao;

import javax.persistence.EntityManager;
import metier.modele.Agence;

public class AgenceDao {
    
    public static void persisterAgence(Agence a) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        em.persist(a);
    }
    
    public static void appliquerModifsAgence(Agence a) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        
        em.merge(a);
    }
}
