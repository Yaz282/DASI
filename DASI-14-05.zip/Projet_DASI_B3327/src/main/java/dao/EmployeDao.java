/** @author Simon Poulet et Yannick Alpou binôme B3327 */

package dao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import metier.modele.Employe;
import metier.modele.Intervention;

public class EmployeDao {
    
    public static void persisterEmploye(Employe e) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        em.persist(e);
    }
    
    public static void appliquerModifsEmploye(Employe e) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        
        em.merge(e);
    }
    
    public static Employe trouverEmployeIdDAO(Long id) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        try{
            TypedQuery<Employe> TypedQuery = em.createQuery("SELECT e FROM Employe e WHERE e.id = :m", Employe.class);
            TypedQuery.setParameter("m", id);
            return TypedQuery.getSingleResult();
        }
        catch (javax.persistence.NoResultException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static Employe authentifierDAO(String email, String mdp) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        try{
            TypedQuery<Employe> TypedQuery = em.createQuery("SELECT c FROM Employe c WHERE c.email = :m AND c.motDePasse = :mdpd", Employe.class);
            TypedQuery.setParameter("m", email);
            TypedQuery.setParameter("mdpd", mdp);
            return TypedQuery.getSingleResult();
        }
        catch (javax.persistence.NoResultException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static List<Employe> listerEmployesDisposDAO(Date heureDispo) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
        
        try{
            Query query = em.createQuery("SELECT e FROM Employe e WHERE e.interEnCours = NULL AND e.horaireDeb < :h AND e.horaireFin > :h");
            query.setParameter("h",heureDispo);
            return query.getResultList();
        }
        catch (javax.persistence.NoResultException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static List<Intervention> listerInterventionsJourneeDAO(Employe e) {
        EntityManager em;
        em = JpaUtil.obtenirContextePersistance();
        
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        
        Date debutJournee = calendar.getTime();
        
        try{
            Query query = em.createQuery("SELECT i FROM Intervention i WHERE i.employe = :e AND i.dateDemande < :dateMax AND i.dateDemande > :dateMin ");
            query.setParameter("e",e);
            query.setParameter("dateMax",new Date());
            query.setParameter("dateMin",debutJournee);
            return query.getResultList();
        }
        catch (javax.persistence.NoResultException exc) {
            exc.printStackTrace();
            return null;
        }
    }
}
