/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fkoch
 */
 package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import metier.modele.Client;
import metier.modele.Employe;
import metier.modele.Intervention;
import metier.modele.InterventionAnimal;
import metier.modele.InterventionIncident;
import metier.modele.InterventionLivraison;
import static metier.modele.InterventionLivraison_.entreprise;
import metier.service.Services;


 public class ActionDemandeIntervention extends Action { 
// Héritage de la classe abstraite Action

 @Override
     public void executer(HttpServletRequest request) { // Implémentation de la méthode Action.executer()
         
         // Instanciation de la classe de Service
        Services service = new Services();


         // Récupération des Paramètres de la session
        HttpSession session = request.getSession ( true ) ;
        long id = (long) session.getAttribute("id");
       Client client = Services.trouverClientParID(id);
        
        //String client = (String) request.getParameter("client");
        
        //String description = (String) session.getAttribute("description");
        String type =request.getParameter("type");
        String description =request.getParameter("description");
        String objet =request.getParameter("objet");
        String animal =request.getParameter("animal");
        String entreprise =request.getParameter("entreprise");
        
        
        Intervention monIntervention=null;
        
        
        if (type.equals("InterventionAnimal")) {
                 monIntervention = new InterventionAnimal( animal, description, client);
                 System.out.println("laaaaaaaaaaaaaaa");
                 System.out.println("la");
             }
             else if (type.equals("InterventionIncident")) {
                 monIntervention = new InterventionIncident( description,client);
             }
             else if (type.equals("InterventionLivraison"))  {
                 monIntervention = new InterventionLivraison( entreprise, objet, description, client);
             };
     
        
        // Appel des Services Métiers (= méthodes de la classe de Service)
        int verif = service.ajouterIntervention(monIntervention);

        // Vérifier le retour de la fonction authentifier pour gérer si c'est null : Gérer  nous même le cas ou client est nul donc mdp erroné
        // Stockage des Résultats dans les Attributs de la Requête
        request.setAttribute("verif", verif);


        // Bien revoir les dates 
    }

}
