/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fkoch
 */
 package action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import metier.modele.Client;
import metier.service.Services;


 public class ActionInscription extends Action { 
// Héritage de la classe abstraite Action

 @Override
     public void executer(HttpServletRequest request) { // Implémentation de la méthode Action.executer()

         // Récupération des Paramètres de la Requête
         String nom =request.getParameter("nom");
         String prenom = request.getParameter("prenom");
         String mail = request.getParameter("mail");
         String tel = request.getParameter("tel");
         String dateNaissanceStr = request.getParameter("dateNaissance");
         String adresse = request.getParameter("adresse");
         String motDePasse = request.getParameter("motDePasse");
         String motDePasseConfirme = request.getParameter("motDePasseConfirme");


         // Instanciation de la classe de Service
         Services service = new Services();
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date dateNaissance=null;
     try {
         dateNaissance = sdf.parse(dateNaissanceStr);
     } catch (ParseException ex) {
         Logger.getLogger(ActionInscription.class.getName()).log(Level.SEVERE, null, ex);
     }
        

        Client client = new Client(nom,prenom, mail,  motDePasse, tel, dateNaissance,adresse);
        int verif;

         // Appel des Services Métiers (= méthodes de la classe de Service)
         if(motDePasse.equals(motDePasseConfirme)){
            verif = service.inscrireClient(client);
         }
         else{
          verif=-1;
         }
         // Vérifier le retour de la fonction authentifier pour gérer si c'est null : Gérer  nous même le cas ou client est nul donc mdp erroné

         // Stockage des Résultats dans les Attributs de la Requête
         request.setAttribute("verif", verif);    

         // If pour vérifier si authentification client ou Authentifcation Employee 

     }

 }
    /*public ActionAuthentification(Service service) {
        super(service);
    }*/


