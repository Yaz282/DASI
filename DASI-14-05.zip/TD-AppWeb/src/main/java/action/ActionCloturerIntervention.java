/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fkoch
 */
 package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import metier.modele.Client;
import metier.modele.Employe;
import metier.service.Services;


 public class ActionCloturerIntervention extends Action { 
// Héritage de la classe abstraite Action

 @Override
     public void executer(HttpServletRequest request) { // Implémentation de la méthode Action.executer()

       // Récupération des Paramètres de la Requête
            HttpSession session = request.getSession(true);
            long id=(long)session.getAttribute("id");
            
            Employe employe = Services.trouverEmployeParID(id);
            
            String commentaire = request.getParameter("commentaire");
            String statut=request.getParameter("statut");
             System.out.println(commentaire);
             System.out.println("Statut " +statut);
             
             boolean statutBool=true;
             
             if(statut.equals("1")){
                 statutBool=true;
             }
             else{
                 statutBool=false;
             }

         // Instanciation de la classe de Service
         Services service = new Services();

         // Appel des Services Métiers (= méthodes de la classe de Service)
         // Try Catch pour gérer Exception
           service.terminerInterventionEnCours(employe,statutBool,commentaire);
     
         // Vérifier le retour de la fonction authentifier pour gérer si c'est null : Gérer  nous même le cas ou client est nul donc mdp erroné

      
         


         // If pour vérifier si authentification client ou Authentifcation Employee 

     }

 }
    /*public ActionAuthentification(Service service) {
        super(service);
    }*/