/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.insalyon.dasi.educatif.ihm.web.serialisation;

 import com.google.gson.Gson;
 import com.google.gson.GsonBuilder;
 import com.google.gson.JsonArray;
 import com.google.gson.JsonObject;
 import java.io.IOException;
 import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
 import java.util.List;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
import metier.modele.Client;
import metier.modele.Intervention;
import metier.modele.Intervention.Stat;
import metier.modele.InterventionAnimal;
import metier.modele.InterventionIncident;
import metier.modele.InterventionLivraison;
import static metier.modele.Intervention_.client;



public class SerialisationAccueilClient extends Serialisation { // Héritage de la classe abstraite Serialisation

    @Override
    public void serialiser(HttpServletRequest request, HttpServletResponse response) throws IOException { // Implémentation de la méthode Serialisation.serialiser()

        JsonObject container = new JsonObject(); // Objet "conteneur JSON" pour structurer les données à sérialiser
        
         // Lecture des Attributs de la Requête (stockés par l'Action)
         List<Intervention> listeIntervention = (List<Intervention>)request.getAttribute("listeIntervention");
        
         // Création d'un tableau JSON d'interventions
         JsonArray jsonListeIntervention = new JsonArray();
        
         for (Intervention intervention : listeIntervention) {
        
         JsonObject jsonIntervention = new JsonObject(); // Création d'un objet JSON pour une intervention
        
         // Ajout de propriétés à ce nouvel objet JSON: numero, nom, prenom
         String pattern = "dd/MM/yyyy HH:mm:ss";
         DateFormat df = new SimpleDateFormat(pattern);
         Date date = intervention.getDateDemande();        
         String dateString = df.format(date);
         jsonIntervention.addProperty( "dateDemande", dateString  ); //mettre la date en string ici ???
         
         String typeInt=null;
         
             if (intervention instanceof InterventionAnimal) {
                 typeInt = "Animal";
             }
             else if (intervention instanceof InterventionIncident) {
                 typeInt = "Incident";
             }
             else if (intervention instanceof InterventionLivraison) {
                 typeInt = "Livraison";
             }
         
         jsonIntervention.addProperty( "typeIntervention",  typeInt ); 

         boolean etat=false;
         String statutStr = null;
            Stat statut=intervention.getStatut();
            if (statut ==Stat.EN_COURS) {
                statutStr = "En cours";
                etat=false;
            } else if (statut ==Stat.REUSSIE) {
                statutStr = "Succès";
                etat=true;
            } else if (statut ==Stat.ECHOUEE) {
                statutStr = "Echec";
                etat=true;
            }
            
            jsonIntervention.addProperty( "statut",  statutStr );
             jsonIntervention.addProperty( "etat", etat  );

       
         jsonListeIntervention.add(jsonIntervention); // Ajout de l'objet au tableau JSON
         }
        
         container.add("listeIntervention", jsonListeIntervention); // Ajout du tableau JSON d'étudiants au conteneur JSON
        
         // Formattage de la structure de données JSON => Écriture sur le flux de sortie de la Réponse
         PrintWriter out = this.getWriter(response);
         Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
         gson.toJson(container, out);
         out.close();
         }
}
