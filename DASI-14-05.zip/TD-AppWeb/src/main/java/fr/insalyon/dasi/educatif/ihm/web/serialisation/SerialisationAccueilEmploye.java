/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.insalyon.dasi.educatif.ihm.web.serialisation;

import javax.servlet.http.HttpServletRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import metier.modele.Client;
import metier.modele.Intervention;
import metier.modele.InterventionAnimal;
import metier.modele.InterventionIncident;
import metier.modele.InterventionLivraison;
import static metier.modele.Intervention_.client;

/**
 *
 * @author ysbai
 */
public class SerialisationAccueilEmploye extends Serialisation { // Héritage de la classe abstraite Serialisation

    @Override
    public void serialiser(HttpServletRequest request, HttpServletResponse response) throws IOException { // Implémentation de la méthode Serialisation.serialiser()

        JsonObject container = new JsonObject(); // Objet "conteneur JSON" pour structurer les données à sérialiser

        // Lecture des Attributs de la Requête (stockés par l'Action)
        double distance = (double) request.getAttribute("distance");
        Intervention interEnCours = (Intervention) request.getAttribute("interEnCours");
        System.out.println(distance);

        // Création d'un tableau JSON d'interventions
        JsonObject jsonIntervention = new JsonObject();

        String distanceStr = String.valueOf(distance);

        if (interEnCours != null) {
            // On recupère la classe 
            String typeInt = null;
            if (interEnCours instanceof InterventionAnimal) {
                typeInt = "Animal";
            } else if (interEnCours instanceof InterventionIncident) {
                typeInt = "Incident";
            } else if (interEnCours instanceof InterventionLivraison) {
                typeInt = "Livraison";
            }
            //On recupère la date en string 
            String pattern = "dd/MM/yyyy HH:mm:ss";
            DateFormat df = new SimpleDateFormat(pattern);
            Date date = interEnCours.getDateDemande();
            String dateString = df.format(date);

            jsonIntervention.addProperty("type", typeInt);
            jsonIntervention.addProperty("date", dateString);
            jsonIntervention.addProperty("description", interEnCours.getDescription());
            container.addProperty("interventionExistante", true);
            container.add("intervention", jsonIntervention);
            System.out.println(typeInt);
            System.out.println(dateString);
            System.out.println(interEnCours.getDescription());

        } else {
            container.addProperty("interventionExistante", false);
        }

        container.addProperty("distance", distanceStr); // Ajout du tableau JSON d'étudiants au conteneur JSON

        // Formattage de la structure de données JSON => Écriture sur le flux de sortie de la Réponse
        PrintWriter out = this.getWriter(response);
        Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
        gson.toJson(container, out);
        out.close();
    }
}
