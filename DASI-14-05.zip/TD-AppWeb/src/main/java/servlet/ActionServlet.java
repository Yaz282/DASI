package servlet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import action.Action;
import action.ActionAuthentification;
import action.ActionDemandeIntervention;
import action.ActionInscription;
import action.ActionAccueilClient;
import action.ActionAccueilEmploye;
import action.ActionCloturerIntervention;
import action.ActionDetailInterventionEmploye;
import action.ActionHistoriqueEmploye;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dao.JpaUtil;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.Serialisation;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationAuthentification;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationDemandeIntervention;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationInscription;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationAccueilClient;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationAccueilEmploye;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationCloturerIntervention;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationDetailInterventionEmploye;
import fr.insalyon.dasi.educatif.ihm.web.serialisation.SerialisationHistoriqueEmploye;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author fkoch
 */
@WebServlet(urlPatterns = {"/ActionServlet"})
public class ActionServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        super.init();
        JpaUtil.init();
    }

    @Override
    public void destroy() {
        JpaUtil.destroy();
        super.destroy();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getSession(true); // Initialisation de la Session
        request.setCharacterEncoding("UTF-8"); // Encodage des paramètres de la requête (pour une lecture correcte)

        String todo = request.getParameter("todo");

        Action action = null;
        Serialisation serialisation = null;

        System.out.println("todo = " + todo);

        switch (todo) {
            case "connecter": { // Si le paramètre "todo" est "connecter"
                 action = new ActionAuthentification(); // Choix de l'Action
                 serialisation = new SerialisationAuthentification(); // Choix de la Serialisation
                 break;
            }
            
            case "inscrire": { 
                 action = new ActionInscription(); // Choix de l'Action
                 serialisation = new SerialisationInscription(); // Choix de la Serialisation
                  break;

            }           
            
            
            case "accueilClient": { 
                 action = new ActionAccueilClient(); // Choix de l'Action
                 serialisation = new SerialisationAccueilClient(); // Choix de la Serialisation
                 break;

            }
            
            case "demandeIntervention":{
                action = new ActionDemandeIntervention(); // Choix de l'Action
                serialisation = new SerialisationDemandeIntervention(); // Choix de la Serialisation
                break;
            }                    

            case "accueilEmploye": { 
                 action = new ActionAccueilEmploye(); // Choix de l'Action
                serialisation = new SerialisationAccueilEmploye(); // Choix de la Serialisation
                break;

            }
            case "historiqueEmploye": {
                action = new ActionHistoriqueEmploye(); // Choix de l'Action
                serialisation = new SerialisationHistoriqueEmploye(); // Choix de la Serialisation
                break;

            }
           case "detailInterventionEmploye": {
                action = new ActionDetailInterventionEmploye(); // Choix de l'Action
                serialisation = new SerialisationDetailInterventionEmploye(); // Choix de la Serialisation
                break;

            }  
           case "cloturer": {
                action = new ActionCloturerIntervention(); // Choix de l'Action
                serialisation = new SerialisationCloturerIntervention(); // Choix de la Serialisation
                break;

            }   
           


        }
        
        if (action != null && serialisation != null) {
            action.executer(request); // Exécuter l'Action
            serialisation.serialiser(request, response); // Sérialiser le résultat de l'Action
        } else { // Erreur: pas d'Action ou de Sérialisation pour traiter cette requête
            response.sendError(400, "Bad Request (pas d'Action ou de Serialisation pour traiter cette requete)");
        }

    }

}

 
    

    /*
      
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
 /*  out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ActionServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ActionServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
          
        }*/
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   /* @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
*/
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
  /*  @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }*/

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
   /* @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
*/